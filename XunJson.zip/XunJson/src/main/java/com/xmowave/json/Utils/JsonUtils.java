package com.xmowave.json.Utils;

public class JsonUtils {
    static {
        System.loadLibrary("XunJson");
    }

    public static native String parseJson(String json, String key);
    public static native String toJson(String key, String value);
    public static native String mergeJson(String[] jsonArray);
}
