#include <jni.h>
#include <string>
#include <vector>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_xmowave_json_Utils_JsonUtils_parseJson(JNIEnv *env, jclass, jstring json, jstring key) {
    const char *cJson = env->GetStringUTFChars(json, nullptr);
    const char *cKey = env->GetStringUTFChars(key, nullptr);

    std::string jsonStr(cJson);
    std::string keyStr(cKey);

    env->ReleaseStringUTFChars(json, cJson);
    env->ReleaseStringUTFChars(key, cKey);

    size_t keyPos = jsonStr.find("\"" + keyStr + "\"");
    if (keyPos == std::string::npos) return env->NewStringUTF("");

    size_t colonPos = jsonStr.find(":", keyPos);
    if (colonPos == std::string::npos) return env->NewStringUTF("");

    size_t valueStart = colonPos + 1;
    while (valueStart < jsonStr.size() && (jsonStr[valueStart] == ' ' || jsonStr[valueStart] == '"'))
        valueStart++;

    size_t valueEnd = valueStart;
    while (valueEnd < jsonStr.size() && jsonStr[valueEnd] != ',' && jsonStr[valueEnd] != '}' && jsonStr[valueEnd] != '"')
        valueEnd++;

    std::string value = jsonStr.substr(valueStart, valueEnd - valueStart);
    return env->NewStringUTF(value.c_str());
}

// 生成 {"key": "value"} 格式的 JSON
extern "C"
JNIEXPORT jstring JNICALL
Java_com_xmowave_json_Utils_JsonUtils_toJson(JNIEnv *env, jclass, jstring key, jstring value) {
    const char *cKey = env->GetStringUTFChars(key, nullptr);
    const char *cValue = env->GetStringUTFChars(value, nullptr);

    std::string jsonStr = "{\"" + std::string(cKey) + "\": \"" + std::string(cValue) + "\"}";

    env->ReleaseStringUTFChars(key, cKey);
    env->ReleaseStringUTFChars(value, cValue);

    return env->NewStringUTF(jsonStr.c_str());
}

// 合并多个 JSON（变长参数）
extern "C"
JNIEXPORT jstring JNICALL
Java_com_xmowave_json_Utils_JsonUtils_mergeJson(JNIEnv *env, jclass, jobjectArray jsonArray) {
    jsize len = env->GetArrayLength(jsonArray);
    std::string mergedJson = "{";

    for (jsize i = 0; i < len; i++) {
        jstring jsonStr = (jstring) env->GetObjectArrayElement(jsonArray, i);
        const char *cJson = env->GetStringUTFChars(jsonStr, nullptr);

        std::string trimmedJson = std::string(cJson);
        if (trimmedJson.front() == '{' && trimmedJson.back() == '}') {
            trimmedJson = trimmedJson.substr(1, trimmedJson.size() - 2);
        }

        if (!trimmedJson.empty()) {
            if (mergedJson.length() > 1) mergedJson += ", ";
            mergedJson += trimmedJson;
        }

        env->ReleaseStringUTFChars(jsonStr, cJson);
        env->DeleteLocalRef(jsonStr);
    }

    mergedJson += "}";
    return env->NewStringUTF(mergedJson.c_str());
}